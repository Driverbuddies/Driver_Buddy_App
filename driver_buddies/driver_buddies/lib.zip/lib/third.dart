import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    home: DriverInfoPage(),
  ));
}

class DriverInfoPage extends StatelessWidget {
  const DriverInfoPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "DRIVEU",
                style: TextStyle(
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Private Car Driver",
                style: TextStyle(
                  fontSize: 18,
                  fontStyle: FontStyle.normal,
                  color: Color.fromARGB(255, 0, 49, 2),
                ),
              ),
              const SizedBox(height: 30),
              const Text(
                "Welcome to DriveU Driver",
                style: TextStyle(
                  fontSize: 35,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 0, 49, 2),
                ),
              ),
              const SizedBox(height: 20),
              const SizedBox(height: 20),
              const SizedBox(height: 20),
              const Center(
                child: CircleAvatar(
                    // Replace with the actual path to the driver's photo
                    ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Driver Name", // Replace with the driver's name
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 0, 49, 2),
                ),
              ),
              const SizedBox(height: 20),
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                    "Love working with DriveU since\n there is no limitation on earnings\n and no restrictions. Thank you\n for your support.",
                    style: TextStyle(
                      fontSize: 20,
                      color: Color.fromARGB(255, 1, 40, 18), // ,
                    )),
              ),
              const SizedBox(height: 100),
              ElevatedButton(
                onPressed: () {
                  // Implement your logic when the "JOIN AS A DRIVER" button is pressed
                },
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all(const Color.fromARGB(255, 1, 46, 14)),
                  padding: MaterialStateProperty.all(
                      const EdgeInsets.symmetric(horizontal: 150, vertical: 40)),
                ),
                child: const Text("JOIN AS A DRIVER"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
