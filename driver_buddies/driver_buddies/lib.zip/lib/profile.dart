import 'package:flutter/material.dart';
import 'booking_page.dart';
import 'history.dart';
import 'upcomingbooking.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: NameCompanyPage(),
    );
  }
}

class NameCompanyPage extends StatelessWidget {
  const NameCompanyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Name Company'),
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start, // Align items to the left
        children: [
          // Display the profile picture
          const CircleAvatar(
            // You can set the user's profile picture here
            radius: 90,
            backgroundImage: AssetImage('your_image_path.jpg'),
          ),
          const SizedBox(
              height: 16), // Add spacing between profile picture and full name
          // Display the full name
          const Text(
            'fullName', // Replace with the actual full name
            style: TextStyle(
              fontSize: 20, // Adjust the font size as needed
              fontWeight: FontWeight.bold, // Add other text styles if needed
            ),
          ),
          const SizedBox(height: 16), // Add more spacing if necessary
          ListTile(
            leading: const Icon(Icons.schedule), // Upcoming Bookings
            title: const Text('Upcoming Bookings'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const BookingsPage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.calendar_today), // Booking
            title: const Text('Booking'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const BookingPage()),
              );
              // Handle navigation to booking page
            },
          ),
          ListTile(
            leading: const Icon(Icons.history), // History
            title: const Text('History'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const HistoryPage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.monetization_on), // Earn Money
            title: const Text('Earn Money'),
            onTap: () {
              // Handle navigation to earn money page
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout), // Logout
            title: const Text('Logout'),
            onTap: () {
              // Handle logout functionality
            },
          ),
        ],
      ),
    );
  }
}
