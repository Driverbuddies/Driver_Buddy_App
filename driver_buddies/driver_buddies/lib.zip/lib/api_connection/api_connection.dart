class API {
  static const hostConnect = "http://192.168.29.49/driver/upload.php";
}
