import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bookings Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const BookingsPage(),
    );
  }
}

class BookingsPage extends StatefulWidget {
  const BookingsPage({super.key});

  @override
  _BookingsPageState createState() => _BookingsPageState();
}

class _BookingsPageState extends State<BookingsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Upcoming Bookings'),
      ),
      body: ListView.builder(
        itemCount: 5, // number of bookings
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.all(8),
            child: ListTile(
              leading: const Icon(Icons.event_note, color: Colors.blue),
              title: Text('Booking #$index'),
              subtitle: const Text('01/01/2022 - 01/10/2022'),
              trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue),
            ),
          );
        },
      ),
    );
  }
}
