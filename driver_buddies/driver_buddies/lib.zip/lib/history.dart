import 'package:flutter/material.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Booking History'),
      ),
      body: ListView(
        children: const <Widget>[
          // Display a list of past bookings here
          ListTile(
            title: Text('Booking 1'),
          ),
          ListTile(
            title: Text('Booking 2'),
          ),
        ],
      ),
    );
  }
}
