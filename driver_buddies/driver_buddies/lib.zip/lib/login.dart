import 'package:flutter/material.dart';
import 'firstpage.dart';
import 'database_helper.dart';
import 'profile.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
    );
  }
}

// ignore: must_be_immutable
class LoginPage extends StatelessWidget {
  LoginPage({Key? key}) : super(key: key);
  final DatabaseHelper dbHelper = DatabaseHelper();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Map<String, dynamic>? registrationUser;
  Future<void> _login(BuildContext context) async {
    final String email = emailController.text;
    final String password = passwordController.text;

    Map<String, dynamic>? registrationUser;
    Map<String, dynamic>? loginUser;

    if (loginUser != null && loginUser['password'] == password) {
      // Handle login for login user
      // Navigate to the profile page or perform any other action
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const NameCompanyPage(),
        ),
      );
    } else if (registrationUser != null) {
      // Handle login for registration user
      // You can display a message or take any other action
    } else {
      // Handle login failure
      // You can display an error message or take any other action
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Title Text
              const Text(
                'Test',
                style: TextStyle(
                  fontSize: 24.0,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 30.0),

              // Email Field
              TextFormField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.person),
                  labelText: 'User ID',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 20.0),

              // Password Field
              TextFormField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.lock),
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
              ),

              const SizedBox(height: 20.0),

              // Forgot Password
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Add your 'Forgot Password' functionality here
                  },
                  child: const Text('Forgot Password?'),
                ),
              ),

              const SizedBox(height: 20.0),

              // Login Button
              ElevatedButton(
                onPressed: () {
                  _login(context); // Call the login function
                },
                child: const Text('Login'),
              ),

              const SizedBox(height: 10.0),

              // Sign In with Google Button
              ElevatedButton.icon(
                onPressed: () {
                  // Add your Google sign-in functionality here
                },
                icon: const Icon(Icons.g_translate),
                label: const Text('Sign in with Google'),
              ),

              // Sign In with Facebook Button

              // Sign In with Mobile Number Button
              ElevatedButton.icon(
                onPressed: () {
                  // Add your mobile number sign-in functionality here
                },
                icon: const Icon(Icons.phone_android),
                label: const Text('Sign in with Mobile Number'),
              ),

              const SizedBox(height: 10.0),

              // Sign Up Button
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return const MyApps();
                  }));
                },
                child: const Text("Don't have an account? Sign up."),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
