import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApps());
}

class MyApps extends StatelessWidget {
  const MyApps({super.key, Key? keyss});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Upload(),
    );
  }
}

class Upload extends StatefulWidget {
  const Upload({super.key, Key? keys});

  @override
  _UploadState createState() => _UploadState();
}

class _UploadState extends State<Upload> {
  DateTime selectedDate = DateTime.now();

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController aadharController = TextEditingController();
  TextEditingController dlController = TextEditingController();
  TextEditingController issueDateController = TextEditingController();
  TextEditingController expiryDateController = TextEditingController();
  TextEditingController referredByController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  String message = '';
  String aadharMessage = '';
  String dlMessage = '';
  String passwordMessage = '';

  bool isEmailValid(String email) {
    final emailRegex = RegExp(r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$');
    return emailRegex.hasMatch(email);
  }

  Future<void> _selectDate(
      BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1900),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        controller.text = formatDate(picked, [yyyy, '-', mm, '-', dd]);
      });
    }
  }

  bool isDateValid(DateTime selectedDate) {
    final now = DateTime.now();
    var age = now.year - selectedDate.year;

    if (now.month < selectedDate.month ||
        (now.month == selectedDate.month && now.day < selectedDate.day)) {
      age--;
    }

    return age >= 18;
  }

  Future<void> _sendDataToServer() async {
  final response = await http.post(
    Uri.parse('https://localhost:3000/register'), // Replace with your API endpoint
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: jsonEncode(<String, String>{
      'name': nameController.text,
      'email': emailController.text,
      'dob': dobController.text,
      'aadhar': aadharController.text,
      'dl': dlController.text,
      'issue_date': issueDateController.text,
      'expiry_date': expiryDateController.text,
      'referred_by': referredByController.text,
      'password': passwordController.text,
    }),
  );

  if (response.statusCode == 200) {
    // Data sent successfully to the server
    // You can handle the response as needed
    print('Data sent successfully');
  } else {
    // Handle errors when sending data to the server
    print('Error sending data to the server');
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 20),
                const Text(
                  "Upload Your Information",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Personal ID Proof",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          labelText: 'Full Name (Driving License)',
                          hintText:
                              'Enter full name as per your driving license',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.camera_alt),
                          onPressed: () {
                            // Implement camera image upload logic here
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.photo),
                          onPressed: () {
                            // Implement gallery image upload logic here
                          },
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Email ID',
                    hintText: 'eg: xxxx@xxxx.com',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  controller: emailController,
                  onChanged: (enteredEmail) {
                    setState(() {
                      if (isEmailValid(enteredEmail)) {
                        message = '';
                      } else {
                        message = 'Please enter a valid email address!';
                      }
                    });
                  },
                ),
                Text(
                  message,
                  style: const TextStyle(
                    color: Colors.red,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: dobController,
                        decoration: const InputDecoration(
                          labelText: 'Enter Date of Birth',
                          hintText: 'eg: yyyy-MM-dd',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: () {
                        _selectDate(context, dobController);
                      },
                    ),
                  ],
                ),
                if (dobController.text.isNotEmpty)
                  isDateValid(selectedDate)
                      ? const Text("")
                      : const Text(
                          "Your age should be more than 18 years. Please enter a valid date of birth.",
                          style: TextStyle(color: Colors.red),
                        ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: aadharController,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                  ],
                  decoration: const InputDecoration(
                    labelText: 'Aadhar card number',
                    hintText: 'eg: 12-digit number',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      if (value.length == 12) {
                        aadharMessage = '';
                      } else {
                        aadharMessage =
                            'Aadhar card number should be of 12 digits.';
                      }
                    });
                  },
                ),
                Text(
                  aadharMessage,
                  style: const TextStyle(
                    color: Colors.red,
                  ),
                ),
                const SizedBox(height: 20),
                const Text("Upload your Aadhar Card:"),
                ElevatedButton(
                  onPressed: () {
                    // Implement file upload for Aadhar Card
                  },
                  child: const Text('Upload File'),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: dlController,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                  ],
                  decoration: const InputDecoration(
                    labelText: 'Driving License number',
                    hintText: 'eg: 16-digit number',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      if (value.length == 16) {
                        dlMessage = '';
                      } else {
                        dlMessage =
                            'Driving License number should be of 16 digits.';
                      }
                    });
                  },
                ),
                Text(
                  dlMessage,
                  style: const TextStyle(
                    color: Colors.red,
                  ),
                ),
                const Text("Upload your Driving License:"),
                ElevatedButton(
                  onPressed: () {
                    // Implement file upload for Driving License
                  },
                  child: const Text('Upload File'),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: issueDateController,
                        decoration: const InputDecoration(
                          labelText: 'Issue Date',
                          hintText: 'yyyy-MM-dd',
                          border: OutlineInputBorder(),
                        ),
                        onTap: () {
                          _selectDate(context, issueDateController);
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextFormField(
                        controller: expiryDateController,
                        decoration: const InputDecoration(
                          labelText: 'Expiry Date',
                          hintText: 'yyyy-MM-dd',
                          border: OutlineInputBorder(),
                        ),
                        onTap: () {
                          _selectDate(context, expiryDateController);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: referredByController,
                  decoration: const InputDecoration(
                    labelText: 'Referred By (Optional)',
                    hintText: 'eg: XXXXXXX',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),

                // Create Password field
                TextFormField(
                  controller: passwordController,
                  decoration: const InputDecoration(
                    labelText: 'Create Password',
                    hintText: 'Enter your password',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                ),
                const SizedBox(height: 20),
                // Confirm Password field
                TextFormField(
                  controller: confirmPasswordController,
                  decoration: const InputDecoration(
                    labelText: 'Confirm Password',
                    hintText: 'Re-enter your password',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                  onChanged: (value) {
                    setState(() {
                      if (passwordController.text == value) {
                        passwordMessage = '';
                      } else {
                        passwordMessage = 'Passwords do not match';
                      }
                    });
                  },
                ),
                Text(
                  passwordMessage,
                  style: const TextStyle(
                    color: Colors.red,
                  ),
                ),
                const SizedBox(height: 20),

                // Continue button

                ElevatedButton(
                  onPressed:
                      _sendDataToServer, // Call the method to send data to the server
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    padding: MaterialStateProperty.all(
                      const EdgeInsets.symmetric(horizontal: 120, vertical: 20),
                    ),
                  ),
                  child: const Text(
                    'Continue',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool isFormValid() {
    return isEmailValid(emailController.text) &&
        isDateValid(selectedDate) &&
        aadharMessage.isEmpty &&
        dlMessage.isEmpty &&
        passwordMessage.isEmpty;
  }
}
